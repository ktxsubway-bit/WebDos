@echo off
title Open Screenshots & Recordings
cls
cd ..
if exist .\capture goto opencapture
if not exist dosbox.exe goto done
dosbox -opencaptures explorer.exe
goto done

:opencapture
cd capture
explorer .\
goto done

:done
