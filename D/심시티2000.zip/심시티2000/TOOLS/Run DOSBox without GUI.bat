@echo off
cd ..
if exist dosbox.exe start dosbox -nogui
